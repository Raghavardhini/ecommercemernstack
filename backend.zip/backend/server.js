const port = 4000;
const express = require("express");
const app = express();
const mongoose = require("mongoose");
const jwt = require("jsonwebtoken");
const multer = require("multer");
const path = require("path");
const bcrypt = require("bcryptjs");
const cors = require("cors");
const fs = require("fs");

app.use(cors({ origin: "http://localhost:3000" }));
app.use(express.json());

// MongoDB connection
mongoose.connect("mongodb://localhost:27017/e-commerce", { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.log("MongoDB connection error: ", err));

// Image Storage Engine
const uploadDir = './upload/images';
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: uploadDir,
  filename: (req, file, cb) => {
    cb(null, `${file.fieldname}_${Date.now()}${path.extname(file.originalname)}`);
  }
});

const upload = multer({ storage: storage });

// Image upload route
app.post("/upload", upload.single('product'), (req, res) => {
  res.json({
    success: 1,
    image_url: `http://localhost:4000/images/${req.file.filename}`
  });
});

app.use('/images', express.static(uploadDir));

// Middleware to fetch user from database (verify JWT)
const fetchUser = async (req, res, next) => {
  const token = req.header("auth-token");
  if (!token) {
    return res.status(401).json({ errors: "Please authenticate using a valid token" });
  }
  try {
    const data = jwt.verify(token, "secret_ecom");
    req.user = data.user;
    next();
  } catch (error) {
    return res.status(401).json({ errors: "Please authenticate using a valid token" });
  }
};

// Schema for creating user model
const Users = mongoose.model("Users", new mongoose.Schema({
  name: { type: String },
  email: { type: String, unique: true },
  password: { type: String },
  cartData: { type: Object },
  date: { type: Date, default: Date.now },
}));

// Schema for creating product model
const Product = mongoose.model("Product", new mongoose.Schema({
  id: { type: Number, required: true },
  name: { type: String, required: true },
  image: { type: String, required: true },
  category: { type: String, required: true },
  new_price: { type: Number },
  old_price: { type: Number },
  date: { type: Date, default: Date.now },
  available: { type: Boolean, default: true },
}));

// Route to add a new product
app.post("/addproduct", async (req, res) => {
  try {
    const products = await Product.find({});
    let id = products.length > 0 ? products[products.length - 1].id + 1 : 1;

    const newProduct = new Product({
      id,
      name: req.body.name,
      image: req.body.image,
      category: req.body.category,
      new_price: req.body.new_price,
      old_price: req.body.old_price,
    });

    await newProduct.save();
    res.json({ success: true, name: req.body.name });
  } catch (error) {
    res.status(500).json({ error: "Error adding product" });
  }
});

// Route to fetch all products
app.get("/allproducts", async (req, res) => {
  try {
    const products = await Product.find({});
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: "Error fetching products" });
  }
});

// Login route - Validate user and generate token
app.post('/login', async (req, res) => {
  try {
    const user = await Users.findOne({ email: req.body.email });
    if (user && await bcrypt.compare(req.body.password, user.password)) {
      const token = jwt.sign({ user: { id: user._id } }, 'secret_ecom');
      return res.json({ success: true, token });
    } else {
      return res.status(400).json({ success: false, errors: "Invalid email or password" });
    }
  } catch (error) {
    return res.status(500).json({ error: "Login failed" });
  }
});

// Signup route - Register a new user
app.post('/signup', async (req, res) => {
  try {
    const existingUser = await Users.findOne({ email: req.body.email });
    if (existingUser) {
      return res.status(400).json({ success: false, errors: "User with this email already exists" });
    }

    const hashedPassword = await bcrypt.hash(req.body.password, 10);
    const cart = Array(300).fill(0);

    const newUser = new Users({
      name: req.body.username,
      email: req.body.email,
      password: hashedPassword,
      cartData: cart,
    });

    await newUser.save();
    const token = jwt.sign({ user: { id: newUser._id } }, 'secret_ecom');
    res.json({ success: true, token });
  } catch (error) {
    res.status(500).json({ error: "Error during signup" });
  }
});

// Route to get new collections
app.get("/newcollections", async (req, res) => {
  try {
    const products = await Product.find({});
    const newCollections = products.slice(-8);
    res.json(newCollections);
  } catch (error) {
    res.status(500).json({ error: "Error fetching new collections" });
  }
});

// Route to fetch products popular in women
app.get("/popularinwomen", async (req, res) => {
  try {
    const products = await Product.find({});
    const popularProducts = products.slice(0, 4);
    res.json(popularProducts);
  } catch (error) {
    res.status(500).json({ error: "Error fetching popular products" });
  }
});

// Add product to cart
app.post('/addtocart', fetchUser, async (req, res) => {
  try {
    const user = await Users.findById(req.user.id);
    user.cartData[req.body.itemId] = (user.cartData[req.body.itemId] || 0) + 1;
    await user.save();
    res.json({ success: true, message: "Added to cart" });
  } catch (error) {
    res.status(500).json({ error: "Error adding to cart" });
  }
});

// Remove product from cart
app.post('/removefromcart', fetchUser, async (req, res) => {
  try {
    const user = await Users.findById(req.user.id);
    if (user.cartData[req.body.itemId] > 0) {
      user.cartData[req.body.itemId] -= 1;
    }
    await user.save();
    res.json({ success: true, message: "Removed from cart" });
  } catch (error) {
    res.status(500).json({ error: "Error removing from cart" });
  }
});

// Get cart details
app.post('/getcart', fetchUser, async (req, res) => {
  try {
    const user = await Users.findById(req.user.id);
    res.json(user.cartData);
  } catch (error) {
    res.status(500).json({ error: "Error fetching cart data" });
  }
});

// Route to remove a product by ID
app.post("/removeproduct", async (req, res) => {
  try {
    await Product.findOneAndDelete({ id: req.body.id });
    res.json({ success: true, message: "Product removed" });
  } catch (error) {
    res.status(500).json({ error: "Error removing product" });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});